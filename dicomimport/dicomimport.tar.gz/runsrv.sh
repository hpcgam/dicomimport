cd /opt/dicomimport
python dicomimport.py 
