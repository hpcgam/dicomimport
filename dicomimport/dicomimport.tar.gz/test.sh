
firefox ./test.html
